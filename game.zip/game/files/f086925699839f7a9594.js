function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 文字列からルビをパースする。
       * このパーサは、akashic-labelのデフォルトルビ記法のためのパーサである。
       *
       * このパーサを使う場合、ラベルに与える文字列にJSONのオブジェクトを表す文字列を含むことができる。
       * 文字列中のオブジェクトはルビを表す要素として扱われる。
       * オブジェクトのメンバーには、ルビを表す `rt` と、本文を表す `rb` を含む必要がある。
       * これらのメンバー以外に、RubyOptions型が持つメンバーを含むことができる。
       *
       * 入力の例として、
       * 'これは{"rb":"本文","rt":"ルビ", "rubyFontSize": 2}です。'
       * という文字列が与えられた場合、このパーサは
       * ["これは", {rb:"本文", rt: "ルビ", rubyFontSize: 2}, "です。"]
       * という配列を返す。
       * また、 `{` や `}` は `\\` でエスケープする必要がある。
       * 例として、括弧は `\\{` 、 バックスラッシュは `\\` を用いて表現する。
       * 注意すべき点として、オブジェクトのプロパティ名はダブルクォートでくくられている必要がある。
       */

      function parse(text) {
        var pattern = /^((?:[^\\{]|\\+.)*?)({(?:[^\\}]|\\+.)*?})([\s\S]*)/; // ((?:[^\\{]|\\+.)*?) -> オブジェクトリテラルの直前まで
        // ({(?:[^\\}]|\\+.)*?}) -> 最前のオブジェクトリテラル
        // ([\s\S]*) -> オブジェクトリテラル以降の、改行を含む文字列

        var result = [];

        while (text.length > 0) {
          var parsedText = text.match(pattern);

          if (parsedText !== null) {
            var headStr = parsedText[1];
            var rubyStr = parsedText[2];
            text = parsedText[3];

            if (headStr.length > 0) {
              result.push(headStr.replace(/\\{/g, "{").replace(/\\}/g, "}"));
            }

            var parseResult = JSON.parse(rubyStr.replace(/\\/g, "\\\\"));

            if (parseResult.hasOwnProperty("rt") && parseResult.hasOwnProperty("rb")) {
              parseResult.rt = parseResult.rt.replace(/\\{/g, "{").replace(/\\}/g, "}");
              parseResult.rb = parseResult.rb.replace(/\\{/g, "{").replace(/\\}/g, "}");
              parseResult.text = rubyStr;
              result.push(parseResult);
            } else {
              throw g.ExceptionFactory.createTypeMismatchError("parse", "RubyFragment");
            }
          } else {
            result.push(text.replace(/\\{/g, "{").replace(/\\}/g, "}"));
            break;
          }
        }

        return result;
      }

      exports.parse = parse;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 行に含まれる文字列要素。
       */

      var StringDrawInfo =
      /** @class */
      function () {
        function StringDrawInfo(text, width, glyphs) {
          this.text = text;
          this.width = width;
          this.glyphs = glyphs;
        }

        return StringDrawInfo;
      }();

      exports.StringDrawInfo = StringDrawInfo;
      /**
       * 行に含まれるルビ要素。
       */

      var RubyFragmentDrawInfo =
      /** @class */
      function () {
        function RubyFragmentDrawInfo(fragment, width, rbWidth, rtWidth, glyphs, rubyGlyphs) {
          this.text = fragment.text;
          this.fragment = fragment;
          this.width = width;
          this.rbWidth = rbWidth;
          this.rtWidth = rtWidth;
          this.glyphs = glyphs;
          this.rubyGlyphs = rubyGlyphs;
        }

        return RubyFragmentDrawInfo;
      }();

      exports.RubyFragmentDrawInfo = RubyFragmentDrawInfo;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var rp = require("./RubyParser");

      var fr = require("./FragmentDrawInfo");

      var dr = require("./DefaultRubyParser");
      /**
       * 複数行のテキストを描画するエンティティ。
       * 文字列内の"\r\n"、"\n"、"\r"を区切りとして改行を行う。
       * また、自動改行が有効な場合はエンティティの幅に合わせて改行を行う。
       * 本クラスの利用にはg.Fontが必要となる。
       */


      var Label =
      /** @class */
      function (_super) {
        __extends(Label, _super);
        /**
         * 各種パラメータを指定して `Label` のインスタンスを生成する。
         * @param param このエンティティに対するパラメータ
         */


        function Label(param) {
          var _this = _super.call(this, param) || this;

          _this.text = param.text;
          _this.font = param.font;
          _this.fontSize = param.fontSize;
          _this._lineBreakWidth = param.width;
          _this.lineBreak = "lineBreak" in param ? param.lineBreak : true;
          _this.lineGap = param.lineGap || 0;
          _this.textAlign = "textAlign" in param ? param.textAlign : g.TextAlign.Left;
          _this.textColor = param.textColor;
          _this.trimMarginTop = "trimMarginTop" in param ? param.trimMarginTop : false;
          _this.widthAutoAdjust = "widthAutoAdjust" in param ? param.widthAutoAdjust : false;
          _this.rubyEnabled = "rubyEnabled" in param ? param.rubyEnabled : true;
          _this.fixLineGap = "fixLineGap" in param ? param.fixLineGap : false;
          _this.rubyParser = "rubyParser" in param ? param.rubyParser : dr.parse;
          _this.lineBreakRule = "lineBreakRule" in param ? param.lineBreakRule : undefined;

          if (!param.rubyOptions) {
            param.rubyOptions = {};
          }

          _this.rubyOptions = param.rubyOptions;
          _this.rubyOptions.rubyFontSize = "rubyFontSize" in param.rubyOptions ? param.rubyOptions.rubyFontSize : param.fontSize / 2;
          _this.rubyOptions.rubyFont = "rubyFont" in param.rubyOptions ? param.rubyOptions.rubyFont : _this.font;
          _this.rubyOptions.rubyGap = "rubyGap" in param.rubyOptions ? param.rubyOptions.rubyGap : 0;
          _this.rubyOptions.rubyAlign = "rubyAlign" in param.rubyOptions ? param.rubyOptions.rubyAlign : rp.RubyAlign.SpaceAround;
          _this._lines = [];
          _this._beforeText = undefined;
          _this._beforeTextAlign = undefined;
          _this._beforeFontSize = undefined;
          _this._beforeLineBreak = undefined;
          _this._beforeFont = undefined;
          _this._beforeWidth = undefined;
          _this._beforeRubyEnabled = undefined;
          _this._beforeFixLineGap = undefined;
          _this._beforeTrimMarginTop = undefined;
          _this._beforeWidthAutoAdjust = undefined;
          _this._beforeRubyOptions = {};

          _this._invalidateSelf();

          return _this;
        }
        /**
         * このエンティティの描画キャッシュ無効化をエンジンに通知する。
         * このメソッドを呼び出し後、描画キャッシュの再構築が行われ、各 `g.Renderer` に描画内容の変更が反映される。
         */


        Label.prototype.invalidate = function () {
          this._invalidateSelf();

          _super.prototype.invalidate.call(this);
        };

        Label.prototype.renderCache = function (renderer) {
          if (!this.rubyEnabled && this.fontSize === 0) return;
          renderer.save();
          var currentLineHeight = 0;

          for (var i = 0; i < this._lines.length; ++i) {
            if (this._lines[i].width > 0 && this._lines[i].height > 0) {
              renderer.drawImage(this._lines[i].surface, 0, 0, this._lines[i].width, this._lines[i].height, this._offsetX(this._lines[i].width), currentLineHeight);
            }

            currentLineHeight += this._lines[i].height + this.lineGap;
          }

          if (this.textColor) {
            renderer.setCompositeOperation(g.CompositeOperation.SourceAtop);
            renderer.fillRect(0, 0, this._lineBreakWidth, this.height, this.textColor);
          }

          renderer.restore();
        };
        /**
         * 利用している `g.Surface` を破棄した上で、このエンティティを破棄する。
         * 利用している `g.Font` の破棄は行わないため、 `g.Font` の破棄はコンテンツ製作者が明示的に行う必要がある。
         */


        Label.prototype.destroy = function () {
          this._destroyLines();

          _super.prototype.destroy.call(this);
        };
        /**
         * 禁則処理によって行幅が this.width を超える場合があるため、 `g.CacheableE` のメソッドをオーバーライドする
         */


        Label.prototype.calculateCacheSize = function () {
          // TODO: 最大値の候補に this.width を使用するのは textAlign が g.Center か g.Right の場合に描画に必要なキャッシュサイズを確保するためであり、
          // 最大行幅に対して this.width が大きい場合、余分なキャッシュ領域を確保することになる。
          // これは g.CacheableE にキャッシュ描画位置を調整する cacheOffsetX を導入することで解決される。
          var maxWidth = Math.ceil(this._lines.reduce(function (width, line) {
            return Math.max(width, line.width);
          }, this.width));
          return {
            width: maxWidth,
            height: this.height
          };
        };

        Object.defineProperty(Label.prototype, "lineCount", {
          /**
           * 描画内容の行数を返す
           */
          get: function get() {
            return this._lines.length;
          },
          enumerable: true,
          configurable: true
        });

        Label.prototype._offsetX = function (width) {
          switch (this.textAlign) {
            case g.TextAlign.Left:
              return 0;

            case g.TextAlign.Right:
              return this._lineBreakWidth - width;

            case g.TextAlign.Center:
              return (this._lineBreakWidth - width) / 2;

            default:
              return 0;
          }
        };

        Label.prototype._destroyLines = function () {
          for (var i = 0; i < this._lines.length; i++) {
            if (this._lines[i].surface && !this._lines[i].surface.destroyed()) {
              this._lines[i].surface.destroy();
            }
          }

          this._lines = undefined;
        };

        Label.prototype._invalidateSelf = function () {
          if (this.fontSize < 0) throw g.ExceptionFactory.createAssertionError("Label#_invalidateSelf: fontSize must not be negative.");
          if (this.lineGap < -1 * this.fontSize) throw g.ExceptionFactory.createAssertionError("Label#_invalidateSelf: lineGap must be greater than -1 * fontSize."); // this.width がユーザから変更された場合、this._lineBreakWidth は this.width に追従する。

          if (this._beforeWidth !== this.width) this._lineBreakWidth = this.width;

          if (this._beforeText !== this.text || this._beforeFontSize !== this.fontSize || this._beforeFont !== this.font || this._beforeLineBreak !== this.lineBreak || this._beforeWidth !== this.width && this._beforeLineBreak === true || this._beforeTextAlign !== this.textAlign || this._beforeRubyEnabled !== this.rubyEnabled || this._beforeFixLineGap !== this.fixLineGap || this._beforeTrimMarginTop !== this.trimMarginTop || this._beforeWidthAutoAdjust !== this.widthAutoAdjust || this._isDifferentRubyOptions(this._beforeRubyOptions, this.rubyOptions)) {
            this._updateLines();
          }

          if (this.widthAutoAdjust) {
            // this.widthAutoAdjust が真の場合、 this.width は描画幅に応じてトリミングされる。
            this.width = Math.ceil(this._lines.reduce(function (width, line) {
              return Math.max(width, line.width);
            }, 0));
          }

          var height = this.lineGap * (this._lines.length - 1);

          for (var i = 0; i < this._lines.length; i++) {
            height += this._lines[i].height;
          }

          this.height = height;
          this._beforeText = this.text;
          this._beforeTextAlign = this.textAlign;
          this._beforeFontSize = this.fontSize;
          this._beforeLineBreak = this.lineBreak;
          this._beforeFont = this.font;
          this._beforeWidth = this.width;
          this._beforeRubyEnabled = this.rubyEnabled;
          this._beforeFixLineGap = this.fixLineGap;
          this._beforeTrimMarginTop = this.trimMarginTop;
          this._beforeWidthAutoAdjust = this.widthAutoAdjust;
          this._beforeRubyOptions.rubyFontSize = this.rubyOptions.rubyFontSize;
          this._beforeRubyOptions.rubyFont = this.rubyOptions.rubyFont;
          this._beforeRubyOptions.rubyGap = this.rubyOptions.rubyGap;
          this._beforeRubyOptions.rubyAlign = this.rubyOptions.rubyAlign;
        };

        Label.prototype._updateLines = function () {
          // ユーザのパーサを適用した後にも揃えるが、渡す前に改行記号を replace して統一する
          var fragments = this.rubyEnabled ? this.rubyParser(this.text.replace(/\r\n|\n/g, "\r")) : [this.text]; // Fragment のうち文字列のものを一文字ずつに分解する

          fragments = rp.flatmap(fragments, function (f) {
            if (typeof f !== "string") return f; // サロゲートペア文字を正しく分割する

            return f.replace(/\r\n|\n/g, "\r").match(/[\uD800-\uDBFF][\uDC00-\uDFFF]|[^\uD800-\uDFFF]/g) || [];
          });

          var undrawnLineInfos = this._divideToLines(fragments);

          var lines = [];
          var hasNotChanged = this._beforeFontSize === this.fontSize && this._beforeFont === this.font && !this._isDifferentRubyOptions(this._beforeRubyOptions, this.rubyOptions);

          for (var i = 0; i < undrawnLineInfos.length; i++) {
            var undrawnLineInfo = undrawnLineInfos[i];
            var line = this._lines[i];

            if (hasNotChanged && line !== undefined && undrawnLineInfo.sourceText === line.sourceText && undrawnLineInfo.width === line.width && undrawnLineInfo.height === line.height) {
              lines.push(line);
            } else {
              if (line && line.surface && !line.surface.destroyed()) {
                line.surface.destroy();
              }

              this._drawLineInfoSurface(undrawnLineInfo);

              lines.push(undrawnLineInfo);
            }
          } // 行数が減った場合、使われない行のSurfaceをdestroyする。


          for (var i = lines.length; i < this._lines.length; i++) {
            var line = this._lines[i];

            if (line.surface && !line.surface.destroyed()) {
              line.surface.destroy();
            }
          }

          this._lines = lines;
        };

        Label.prototype._drawLineInfoSurface = function (lineInfo) {
          var lineDrawInfo = lineInfo.fragmentDrawInfoArray;

          var rhi = this._calcRubyHeightInfo(lineDrawInfo);

          var lineSurface = this.scene.game.resourceFactory.createSurface(Math.ceil(lineInfo.width), Math.ceil(lineInfo.height));
          var lineRenderer = lineSurface.renderer();
          lineRenderer.begin();
          lineRenderer.save();
          var rbOffsetY = rhi.hasRubyFragmentDrawInfo || this.fixLineGap ? this.rubyOptions.rubyGap + rhi.maxRubyGlyphHeightWithOffsetY : 0;
          var minMinusOffsetY = lineInfo.minMinusOffsetY;

          for (var i = 0; i < lineDrawInfo.length; i++) {
            var drawInfo = lineDrawInfo[i];

            if (drawInfo instanceof fr.RubyFragmentDrawInfo) {
              this._drawRubyFragmentDrawInfo(lineRenderer, drawInfo, rbOffsetY - minMinusOffsetY, -rhi.minRubyMinusOffsetY);
            } else if (drawInfo instanceof fr.StringDrawInfo) {
              this._drawStringGlyphs(lineRenderer, this.font, drawInfo.glyphs, this.fontSize, 0, rbOffsetY - minMinusOffsetY, 0);
            }

            lineRenderer.translate(drawInfo.width, 0);
          }

          lineRenderer.restore();
          lineRenderer.end();
          lineInfo.surface = lineSurface;
        }; // 文字列の等幅描画


        Label.prototype._drawStringGlyphs = function (renderer, font, glyphs, fontSize, offsetX, offsetY, margin) {
          if (margin === void 0) {
            margin = 0;
          }

          renderer.save();
          renderer.translate(offsetX, offsetY);

          for (var i = 0; i < glyphs.length; i++) {
            var glyph = glyphs[i];
            var glyphScale = fontSize / font.size;
            var glyphWidth = glyph.advanceWidth * glyphScale;

            if (!glyph.isSurfaceValid) {
              glyph = this._createGlyph(glyph.code, font);
              if (!glyph) continue;
            }

            renderer.save();
            renderer.transform([glyphScale, 0, 0, glyphScale, 0, 0]);

            if (glyph.width > 0 && glyph.height > 0) {
              renderer.drawImage(glyph.surface, glyph.x, glyph.y, glyph.width, glyph.height, glyph.offsetX, glyph.offsetY);
            }

            renderer.restore();
            renderer.translate(glyphWidth + margin, 0);
          }

          renderer.restore();
        }; // ルビベースとルビテキストの描画


        Label.prototype._drawRubyFragmentDrawInfo = function (renderer, rubyDrawInfo, rbOffsetY, rtOffsetY) {
          var f = rubyDrawInfo.fragment;
          var rubyFontSize = "rubyFontSize" in f ? f.rubyFontSize : this.rubyOptions.rubyFontSize;
          var rubyAlign = "rubyAlign" in f ? f.rubyAlign : this.rubyOptions.rubyAlign;
          var rubyFont = "rubyFont" in f ? f.rubyFont : this.rubyOptions.rubyFont;
          var isRtWideThanRb = rubyDrawInfo.rtWidth > rubyDrawInfo.rbWidth;
          var width = rubyDrawInfo.width;
          var rtWidth = rubyDrawInfo.rtWidth;
          var rbWidth = rubyDrawInfo.rbWidth;
          var rtStartPositionX;
          var rbStartPositionX;
          var rtUnitMargin;
          var rbUnitMargin;

          switch (rubyAlign) {
            case rp.RubyAlign.Center:
              rtUnitMargin = 0;
              rbUnitMargin = 0;
              rtStartPositionX = isRtWideThanRb ? 0 : (width - rtWidth) / 2;
              rbStartPositionX = isRtWideThanRb ? (width - rbWidth) / 2 : 0;
              break;

            case rp.RubyAlign.SpaceAround:
              rtUnitMargin = rubyDrawInfo.rubyGlyphs.length > 0 ? (width - rtWidth) / rubyDrawInfo.rubyGlyphs.length : 0;
              rbUnitMargin = 0;
              rtStartPositionX = isRtWideThanRb ? 0 : rtUnitMargin / 2;
              rbStartPositionX = isRtWideThanRb ? (width - rbWidth) / 2 : 0;
              break;

            default:
              throw g.ExceptionFactory.createAssertionError("Label#_drawRubyFragmentDrawInfo: unknown rubyAlign.");
          }

          this._drawStringGlyphs(renderer, this.font, rubyDrawInfo.glyphs, this.fontSize, rbStartPositionX, rbOffsetY, rbUnitMargin);

          this._drawStringGlyphs(renderer, rubyFont, rubyDrawInfo.rubyGlyphs, rubyFontSize, rtStartPositionX, rtOffsetY, rtUnitMargin);
        };

        Label.prototype._calcRubyHeightInfo = function (drawInfoArray) {
          var maxRubyFontSize = this.rubyOptions.rubyFontSize;
          var maxRubyGlyphHeightWithOffsetY = 0;
          var maxRubyGap = this.rubyOptions.rubyGap;
          var hasRubyFragmentDrawInfo = false;
          var maxRealDrawHeight = 0;
          var realOffsetY;

          for (var i = 0; i < drawInfoArray.length; i++) {
            var ri = drawInfoArray[i];

            if (ri instanceof fr.RubyFragmentDrawInfo) {
              var f = ri.fragment;

              if (f.rubyFontSize > maxRubyFontSize) {
                maxRubyFontSize = f.rubyFontSize;
              }

              if (f.rubyGap > maxRubyGap) {
                maxRubyGap = f.rubyGap;
              }

              var rubyGlyphScale = (f.rubyFontSize ? f.rubyFontSize : this.rubyOptions.rubyFontSize) / (f.rubyFont ? f.rubyFont.size : this.rubyOptions.rubyFont.size);
              var currentMaxRubyGlyphHeightWithOffsetY = Math.max.apply(Math, ri.rubyGlyphs.map(function (glyph) {
                return glyph.offsetY > 0 ? glyph.height + glyph.offsetY : glyph.height;
              }));
              var currentMinRubyOffsetY = Math.min.apply(Math, ri.rubyGlyphs.map(function (glyph) {
                return glyph.offsetY > 0 ? glyph.offsetY : 0;
              }));

              if (maxRubyGlyphHeightWithOffsetY < currentMaxRubyGlyphHeightWithOffsetY * rubyGlyphScale) {
                maxRubyGlyphHeightWithOffsetY = currentMaxRubyGlyphHeightWithOffsetY * rubyGlyphScale;
              }

              var rubyFont = f.rubyFont ? f.rubyFont : this.rubyOptions.rubyFont;

              var currentRubyStandardOffsetY = this._calcStandardOffsetY(rubyFont);

              var currentFragmentRealDrawHeight = (currentMaxRubyGlyphHeightWithOffsetY - Math.min(currentMinRubyOffsetY, currentRubyStandardOffsetY)) * rubyGlyphScale;

              if (maxRealDrawHeight < currentFragmentRealDrawHeight) {
                maxRealDrawHeight = currentFragmentRealDrawHeight; // その行で描画されるルビのうち、もっとも実描画高さが高い文字が持つoffsetYを求める

                realOffsetY = Math.min(currentMinRubyOffsetY, currentRubyStandardOffsetY) * rubyGlyphScale;
              }

              hasRubyFragmentDrawInfo = true;
            }
          } // ルビが無い行でもfixLineGapが真の場合ルビの高さを使う


          if (maxRubyGlyphHeightWithOffsetY === 0) {
            maxRubyGlyphHeightWithOffsetY = this.rubyOptions.rubyFontSize;
          }

          var minRubyMinusOffsetY = this.trimMarginTop ? realOffsetY : 0;
          return {
            maxRubyFontSize: maxRubyFontSize,
            maxRubyGlyphHeightWithOffsetY: maxRubyGlyphHeightWithOffsetY,
            minRubyMinusOffsetY: minRubyMinusOffsetY,
            maxRubyGap: maxRubyGap,
            hasRubyFragmentDrawInfo: hasRubyFragmentDrawInfo
          };
        };

        Label.prototype._divideToLines = function (fragmentArray) {
          var state = {
            resultLines: [],
            currentStringDrawInfo: new fr.StringDrawInfo("", 0, []),
            currentLineInfo: {
              sourceText: "",
              fragmentDrawInfoArray: [],
              width: 0,
              height: 0,
              minMinusOffsetY: 0,
              surface: undefined
            },
            reservedLineBreakPosition: null
          };

          for (var i = 0; i < fragmentArray.length; i++) {
            this._addFragmentToState(state, fragmentArray, i);
          }

          this._flushCurrentStringDrawInfo(state);

          this._feedLine(state); // 行末ではないが、状態をflushするため改行処理を呼ぶ


          return state.resultLines;
        };

        Label.prototype._addFragmentToState = function (state, fragments, index) {
          var fragment = fragments[index];

          if (state.reservedLineBreakPosition !== null) {
            state.reservedLineBreakPosition--;
          }

          if (state.reservedLineBreakPosition === 0) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);

            state.reservedLineBreakPosition = null;
          }

          if (typeof fragment === "string" && fragment === "\r") {
            /*
            // 行末に改行記号が来た場合、禁則処理によって改行すべきかは判断を保留し、一旦禁則処理による改行はしないことにする
            if (this._needFixLineBreakByRule(state)) {
                this._applyLineBreakRule(index, state);
            }
            */
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);
          } else if (typeof fragment === "string") {
            var code = g.Util.charCodeAt(fragment, 0);
            if (!code) return;

            var glyph = this._createGlyph(code, this.font);

            if (!glyph) return;
            var glyphScale = this.fontSize / this.font.size;
            var glyphWidth = glyph.advanceWidth * glyphScale;

            if (this._needBreakLine(state, glyphWidth)) {
              this._breakLine(state, fragments, index);
            }

            state.currentStringDrawInfo.width += glyphWidth;
            state.currentStringDrawInfo.glyphs.push(glyph);
            state.currentStringDrawInfo.text += fragment;
          } else {
            var ri = this._createRubyFragmentDrawInfo(fragment);

            if (ri.width <= 0) return;

            this._flushCurrentStringDrawInfo(state);

            if (this._needBreakLine(state, ri.width)) {
              this._breakLine(state, fragments, index);
            }

            state.currentLineInfo.width += ri.width;
            state.currentLineInfo.fragmentDrawInfoArray.push(ri);
            state.currentLineInfo.sourceText += fragment.text;
          }
        };

        Label.prototype._createStringGlyph = function (text, font) {
          var glyphs = [];

          for (var i = 0; i < text.length; i++) {
            var code = g.Util.charCodeAt(text, i);
            if (!code) continue;

            var glyph = this._createGlyph(code, font);

            if (!glyph) continue;
            glyphs.push(glyph);
          }

          return glyphs;
        };

        Label.prototype._createGlyph = function (code, font) {
          var glyph = font.glyphForCharacter(code);

          if (!glyph) {
            var str = code & 0xFFFF0000 ? String.fromCharCode((code & 0xFFFF0000) >>> 16, code & 0xFFFF) : String.fromCharCode(code);
            this.game().logger.warn("Label#_invalidateSelf(): failed to get a glyph for '" + str + "' " + "(BitmapFont might not have the glyph or DynamicFont might create a glyph larger than its atlas).");
          }

          return glyph;
        };

        Label.prototype._createRubyFragmentDrawInfo = function (fragment) {
          var glyphs = this._createStringGlyph(fragment.rb, this.font);

          var rubyGlyphs = this._createStringGlyph(fragment.rt, this.rubyOptions.rubyFont);

          var rubyFont = "rubyFont" in fragment ? fragment.rubyFont : this.rubyOptions.rubyFont;
          var rubyFontSize = "rubyFontSize" in fragment ? fragment.rubyFontSize : this.rubyOptions.rubyFontSize;
          var glyphScale = this.fontSize / this.font.size;
          var rubyGlyphScale = rubyFontSize / rubyFont.size;
          var rbWidth = glyphs.length > 0 ? glyphs.map(function (glyph) {
            return glyph.advanceWidth;
          }).reduce(function (pre, cu) {
            return pre + cu;
          }) * glyphScale : 0;
          var rtWidth = rubyGlyphs.length > 0 ? rubyGlyphs.map(function (glyph) {
            return glyph.advanceWidth;
          }).reduce(function (pre, cu) {
            return pre + cu;
          }) * rubyGlyphScale : 0;
          var width = rbWidth > rtWidth ? rbWidth : rtWidth;
          return new fr.RubyFragmentDrawInfo(fragment, width, rbWidth, rtWidth, glyphs, rubyGlyphs);
        };

        Label.prototype._flushCurrentStringDrawInfo = function (state) {
          if (state.currentStringDrawInfo.width > 0) {
            state.currentLineInfo.fragmentDrawInfoArray.push(state.currentStringDrawInfo);
            state.currentLineInfo.width += state.currentStringDrawInfo.width;
            state.currentLineInfo.sourceText += state.currentStringDrawInfo.text;
          }

          state.currentStringDrawInfo = new fr.StringDrawInfo("", 0, []);
        };

        Label.prototype._feedLine = function (state) {
          var glyphScale = this.fontSize / this.font.size;
          var minOffsetY = Infinity;
          var minMinusOffsetY = 0;
          var maxGlyphHeightWithOffsetY = 0;
          state.currentLineInfo.fragmentDrawInfoArray.forEach(function (fragmentDrawInfo) {
            fragmentDrawInfo.glyphs.forEach(function (glyph) {
              if (minMinusOffsetY > glyph.offsetY) {
                minMinusOffsetY = glyph.offsetY;
              } // offsetYの一番小さな値を探す


              if (minOffsetY > glyph.offsetY) minOffsetY = glyph.offsetY;
              var heightWithOffsetY = glyph.offsetY > 0 ? glyph.height + glyph.offsetY : glyph.height;

              if (maxGlyphHeightWithOffsetY < heightWithOffsetY) {
                maxGlyphHeightWithOffsetY = heightWithOffsetY;
              }
            });
          });
          minMinusOffsetY = minMinusOffsetY * glyphScale;
          maxGlyphHeightWithOffsetY = state.currentLineInfo.fragmentDrawInfoArray.length > 0 ? maxGlyphHeightWithOffsetY * glyphScale - minMinusOffsetY : this.fontSize;
          maxGlyphHeightWithOffsetY = Math.ceil(maxGlyphHeightWithOffsetY);

          var rhi = this._calcRubyHeightInfo(state.currentLineInfo.fragmentDrawInfoArray);

          state.currentLineInfo.height = rhi.hasRubyFragmentDrawInfo || this.fixLineGap ? maxGlyphHeightWithOffsetY + rhi.maxRubyGlyphHeightWithOffsetY + rhi.maxRubyGap : maxGlyphHeightWithOffsetY;
          state.currentLineInfo.minMinusOffsetY = minMinusOffsetY;

          if (this.trimMarginTop) {
            var minOffsetYInRange = Math.min(minOffsetY, this._calcStandardOffsetY(this.font)) * glyphScale;
            state.currentLineInfo.height -= minOffsetYInRange;
            state.currentLineInfo.minMinusOffsetY += minOffsetYInRange;
          }

          state.resultLines.push(state.currentLineInfo);
          state.currentLineInfo = {
            sourceText: "",
            fragmentDrawInfoArray: [],
            width: 0,
            height: 0,
            minMinusOffsetY: 0,
            surface: undefined
          };
        };

        Label.prototype._needBreakLine = function (state, width) {
          return this.lineBreak && width > 0 && state.reservedLineBreakPosition === null && state.currentLineInfo.width + state.currentStringDrawInfo.width + width > this._lineBreakWidth && state.currentLineInfo.width + state.currentStringDrawInfo.width > 0; // 行頭文字の場合は改行しない
        };

        Label.prototype._isDifferentRubyOptions = function (ro0, ro1) {
          return ro0.rubyFontSize !== ro1.rubyFontSize || ro0.rubyFont !== ro1.rubyFont || ro0.rubyGap !== ro1.rubyGap || ro0.rubyAlign !== ro1.rubyAlign;
        };

        Label.prototype._calcStandardOffsetY = function (font) {
          // 標準的な高さを持つグリフとして `M` を利用するが明確な根拠は無い
          var text = "M";
          var glyphM = font.glyphForCharacter(text.charCodeAt(0));
          return glyphM.offsetY;
        };
        /** stateのcurrent系プロパティを禁則処理的に正しい構造に再構築する */


        Label.prototype._breakLine = function (state, fragments, index) {
          if (!this.lineBreakRule) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);

            return;
          }

          var correctLineBreakPosition = this.lineBreakRule(fragments, index); // 外部ルールが期待する改行位置

          var diff = correctLineBreakPosition - index;

          if (diff === 0) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);
          } else if (diff > 0) {
            // 先送り改行
            state.reservedLineBreakPosition = diff;
          } else {
            // 巻き戻し改行
            this._flushCurrentStringDrawInfo(state);

            var droppedFragmentDrawInfoArray = []; // currentLineInfoのfragmentDrawInfoArrayを巻き戻す

            while (diff < 0) {
              var fragmentDrawInfoArray = state.currentLineInfo.fragmentDrawInfoArray;
              var lastDrawInfo = fragmentDrawInfoArray[fragmentDrawInfoArray.length - 1];

              if (lastDrawInfo instanceof fr.RubyFragmentDrawInfo) {
                diff++;
                droppedFragmentDrawInfoArray.push(lastDrawInfo);
                fragmentDrawInfoArray.pop();
              } else {
                if (-diff >= lastDrawInfo.text.length) {
                  diff += lastDrawInfo.text.length;
                  droppedFragmentDrawInfoArray.push(lastDrawInfo);
                  fragmentDrawInfoArray.pop();
                } else {
                  var droppedGlyphs = lastDrawInfo.glyphs.splice(diff);
                  var glyphScale = this.fontSize / this.font.size;
                  var droppedDrawInfoWidth = droppedGlyphs.reduce(function (acc, glyph) {
                    return glyph.advanceWidth * glyphScale + acc;
                  }, 0);
                  lastDrawInfo.width -= droppedDrawInfoWidth;
                  var droppedDrawInfoText = lastDrawInfo.text.substring(lastDrawInfo.text.length + diff);
                  lastDrawInfo.text = lastDrawInfo.text.substring(0, lastDrawInfo.text.length + diff);
                  droppedFragmentDrawInfoArray.push(new fr.StringDrawInfo(droppedDrawInfoText, droppedDrawInfoWidth, droppedGlyphs));
                  diff = 0;
                }
              }
            } // currentLineInfoのその他を更新する


            var droppedWidth = 0;
            var droppedSourceText = "";
            droppedFragmentDrawInfoArray.forEach(function (fragment) {
              droppedWidth += fragment.width;
              droppedSourceText += fragment.text;
            });
            state.currentLineInfo.width -= droppedWidth;
            var sourceText = state.currentLineInfo.sourceText;
            state.currentLineInfo.sourceText = sourceText.substr(0, sourceText.length - droppedSourceText.length);

            this._feedLine(state);

            state.currentLineInfo.fragmentDrawInfoArray = droppedFragmentDrawInfoArray;
            state.currentLineInfo.width = droppedWidth;
            state.currentLineInfo.sourceText = droppedSourceText;
          }
        };

        return Label;
      }(g.CacheableE);

      module.exports = Label;
    }, {
      "./DefaultRubyParser": 1,
      "./FragmentDrawInfo": 2,
      "./RubyParser": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      var RubyAlign;

      (function (RubyAlign) {
        /**
         * rtの字間は固定で中央に揃える。
         */
        RubyAlign[RubyAlign["Center"] = 0] = "Center";
        /**
         * rb幅に合わせてrtの字間を揃える。
         */

        RubyAlign[RubyAlign["SpaceAround"] = 1] = "SpaceAround";
      })(RubyAlign = exports.RubyAlign || (exports.RubyAlign = {}));

      function flatmap(arr, func) {
        return Array.prototype.concat.apply([], arr.map(func));
      }

      exports.flatmap = flatmap;
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Label = require("./Label");
      exports.FragmentDrawInfo = require("./FragmentDrawInfo");
      exports.RubyParser = require("./RubyParser");
      exports.RubyAlign = exports.RubyParser.RubyAlign; // tslintが誤動作するので一時的に無効化する

      /* tslint:disable: no-unused-variable */

      var DRP = require("./DefaultRubyParser");

      exports.defaultRubyParser = DRP.parse;
      /* tslint:enable: no-unused-variable */
    }, {
      "./DefaultRubyParser": 1,
      "./FragmentDrawInfo": 2,
      "./Label": 3,
      "./RubyParser": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    8: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 9
    }],
    9: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 6,
      "./Easing": 7
    }],
    10: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 7,
      "./Timeline": 8,
      "./Tween": 9
    }],
    11: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      }); //ボールクラス

      var Ball =
      /** @class */
      function (_super) {
        __extends(Ball, _super);

        function Ball(scene) {
          var _this = _super.call(this, {
            scene: scene,
            src: scene.assets["ball"],
            width: 32,
            height: 32,
            srcX: 32,
            x: 305,
            y: 180
          }) || this;

          _this.isMove = false;
          _this.isCatch = false;
          var b = new g.Sprite({
            scene: scene,
            src: scene.assets["ball"],
            width: 32,
            height: 32,
            y: -6
          });

          _this.append(b);

          _this.stop = function () {
            b.y = -6;
            b.modified();
            _this.isMove = false;
          };

          _this.catch = function () {
            b.y = -18;
            b.modified();
            _this.isMove = false;
            _this.isCatch = true;
          };

          return _this;
        }

        return Ball;
      }(g.Sprite);

      exports.Ball = Ball;
    }, {}],
    12: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var MultiKeyboard = require("./MultiKeyboard");

      var game = g.game;

      var Input =
      /** @class */
      function (_super) {
        __extends(Input, _super);

        function Input(pram) {
          var _this = _super.call(this, pram) || this;

          var scene = pram.scene;
          var timeline = new akashic_timeline_1.Timeline(scene);
          _this.users = {};
          _this.time = 2;
          _this.life = 3;
          var base = new g.E({
            scene: scene,
            width: 1280,
            height: 720,
            scaleX: 0.5,
            scaleY: 0.5,
            anchorX: 0,
            anchorY: 0
          });

          _this.append(base);

          var font = new g.DynamicFont({
            game: game,
            fontFamily: g.FontFamily.SansSerif,
            size: 50,
            fontWeight: 1
          });
          var glyph = JSON.parse(scene.assets["notosansGlyph"].data);
          var keyboardFont = new g.BitmapFont({
            src: scene.assets["notosansFont"],
            map: glyph,
            defaultGlyphWidth: 72,
            defaultGlyphHeight: 72
          });
          var name = new akashic_label_1.Label({
            scene: scene,
            text: "",
            textColor: "black",
            width: 640,
            y: 550,
            x: 50,
            font: font,
            fontSize: 32,
            textAlign: g.TextAlign.Left
          });
          base.append(name);
          var numLabel = new akashic_label_1.Label({
            scene: scene,
            text: "",
            textColor: "black",
            width: 200,
            y: 620,
            x: 900,
            font: font,
            fontSize: 50,
            textAlign: g.TextAlign.Left
          });
          base.append(numLabel); //情報表示(未使用)

          var infoLabel = new akashic_label_1.Label({
            scene: scene,
            text: "",
            textColor: "black",
            width: 400,
            y: 550,
            x: 440,
            font: font,
            fontSize: 40,
            textAlign: g.TextAlign.Center
          });
          base.append(infoLabel); //ヘルプ

          var helpLabel = new akashic_label_1.Label({
            scene: scene,
            text: "ボールをぶつけ合うゲームです\r3回ぶつかるか場外に出ると退場\r自機をクリックでボールが取れます\r最後まで生き残った人の勝ち\r参加人数は無制限です",
            textColor: "black",
            width: 1000,
            y: 150,
            x: 200,
            font: font,
            fontSize: 50,
            textAlign: g.TextAlign.Left
          });
          base.append(helpLabel); //ライフ変更用

          var life = 2;
          base.append(new g.Label({
            scene: scene,
            x: 350,
            y: 460,
            font: font,
            fontSize: 40,
            text: "ライフ"
          }));
          var sprLife = new g.FilledRect({
            scene: scene,
            x: 400,
            y: 510,
            width: 280,
            height: 80,
            cssColor: "white",
            touchable: true
          });
          base.append(sprLife);
          var labelLife = new g.Label({
            scene: scene,
            x: 120,
            y: 10,
            font: font,
            fontSize: 50,
            text: "3"
          });
          sprLife.append(labelLife);
          sprLife.pointDown.add(function (e) {
            if (lastJoinPlayerId !== e.player.id) return;
            life = (life + 1) % 3;
            labelLife.text = "" + (life + 1);
            labelLife.invalidate();
            _this.life = life + 1;
          }); //時間変更用

          var time = 1;
          base.append(new g.Label({
            scene: scene,
            x: 800,
            y: 460,
            font: font,
            fontSize: 40,
            text: "制限時間"
          }));
          var sprTime = new g.FilledRect({
            scene: scene,
            x: 850,
            y: 510,
            width: 280,
            height: 80,
            cssColor: "white",
            touchable: true
          });
          base.append(sprTime);
          var labelTime = new g.Label({
            scene: scene,
            x: 80,
            y: 10,
            font: font,
            fontSize: 50,
            text: "2:00"
          });
          sprTime.append(labelTime);
          sprTime.pointDown.add(function (e) {
            if (lastJoinPlayerId !== e.player.id) return;
            time = (time + 1) % 5;
            labelTime.text = "" + (time + 1) + ":00";
            labelTime.invalidate();
            _this.time = time + 1;
          }); // マルチキーボードインスタンスの生成

          var keyboard = new MultiKeyboard({
            scene: scene,
            font: keyboardFont,
            sceneAssets: scene.assets,
            maxLength: 8,
            y: 720,
            local: true
          });
          base.append(keyboard);
          var state = 1
          /* OFF */
          ;
          var openAsset = scene.assets["open"];
          var closeAsset = scene.assets["close"];
          var buttonAsset = scene.assets["button"];
          var keyboardButton = new g.Pane({
            scene: scene,
            width: openAsset.width,
            height: openAsset.height,
            x: 50,
            y: 610,
            backgroundImage: openAsset,
            touchable: true,
            local: true
          });
          keyboardButton.hide();
          keyboardButton.pointDown.add(function (e) {
            switch (state) {
              case 1
              /* OFF */
              :
                keyboardButton.backgroundImage = g.Util.asSurface(closeAsset);
                timeline.create(keyboard).moveTo(0, 0, 150);
                state = 0
                /* ON */
                ;
                break;

              case 0
              /* ON */
              :
                name.text = keyboard.text;
                name.invalidate();
                keyboardButton.backgroundImage = g.Util.asSurface(openAsset);
                timeline.create(keyboard).moveTo(0, 720, 150);
                state = 1
                /* OFF */
                ;
                e.player.name = keyboard.text;
                g.game.raiseEvent(new g.MessageEvent({
                  msg: "rename",
                  player: e.player
                }));
                break;
            }

            keyboardButton.invalidate();
          });
          base.append(keyboardButton); //受付開始、参加、参加済み、受付終了の表示用

          var joinButton = new g.Pane({
            scene: scene,
            width: buttonAsset.width,
            height: buttonAsset.height,
            x: (1280 - buttonAsset.width) / 2,
            y: 610,
            backgroundImage: buttonAsset,
            touchable: true,
            local: true
          });
          base.append(joinButton);
          joinButton.hide();
          var strStates = ["受付待ち", "参加", "参加済み", "受付終了"];
          var labelState = new g.Label({
            scene: scene,
            font: font,
            text: "受付待ち",
            fontSize: 50,
            y: 10,
            width: buttonAsset.width,
            textAlign: g.TextAlign.Center,
            widthAutoAdjust: false,
            textColor: "white",
            tag: 0,
            local: true
          });
          joinButton.append(labelState); //グローバルイベントでプレイヤー情報追加

          scene.message.add(function (msg) {
            // 関係ないイベントは無視して抜ける
            if (!msg.data || !msg.data.player) return;

            if (msg.data.msg === "start" || msg.data.msg === "add") {
              //受付開始
              var p = msg.data.player;
              var num = Object.keys(_this.users).length;
              p.name = msg.data.msg === "start" ? "ほうそうしゃ" : "げすと" + num;
              _this.users[p.id] = p.name;

              if (p.id === g.game.selfId) {
                name.text = p.name;
                keyboard.text = name.text;
                name.invalidate();
              }

              numLabel.text = num + 1 + "人";
              numLabel.invalidate();

              if (msg.data.msg === "start") {
                if (joinButton.state & 1) {
                  labelState.tag = 1;
                  labelState.text = strStates[labelState.tag];
                  labelState.invalidate();
                  joinButton.show();
                }
              }
            } else if (msg.data.msg === "rename") {
              var p = msg.data.player;
              _this.users[p.id] = p.name;
            } else if (msg.data.msg === "end") {
              //if (Object.keys(this.users).length > 1) {
              _this.endEvent(); // } else {
              // 	infoLabel.text = "人数が足りません";
              // 	infoLabel.invalidate();
              // }

            }
          }); //クリックイベント(ローカル)

          joinButton.pointDown.add(function (e) {
            if (labelState.tag === 2) return; //受付待ち

            if (labelState.tag === 0) {
              keyboardButton.show();
              labelState.tag = 3;
              labelState.text = strStates[labelState.tag];
              labelState.invalidate();
              g.game.raiseEvent(new g.MessageEvent({
                msg: "start",
                player: e.player
              }));
            } //参加
            else if (labelState.tag === 1) {
                keyboardButton.show();
                labelState.tag = 2;
                labelState.text = strStates[labelState.tag];
                labelState.invalidate();
                g.game.raiseEvent(new g.MessageEvent({
                  msg: "add",
                  player: e.player
                }));
              } //受付終了
              else if (labelState.tag === 3) {
                  g.game.raiseEvent(new g.MessageEvent({
                    msg: "end",
                    player: e.player
                  }));
                }
          });
          var lastJoinPlayerId = null;
          g.game.join.add(function (ev) {
            lastJoinPlayerId = ev.player.id;

            if (g.game.selfId === ev.player.id) {
              joinButton.show();
            }
          });

          if (typeof window !== "undefined" && window.RPGAtsumaru) {
            joinButton.show();
          }

          return _this;
        }

        return Input;
      }(g.E);

      exports.Input = Input;
    }, {
      "./MultiKeyboard": 14,
      "@akashic-extension/akashic-label": 5,
      "@akashic-extension/akashic-timeline": 10
    }],
    13: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics3 = function extendStatics(d, b) {
          _extendStatics3 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics3(d, b);
        };

        return function (d, b) {
          _extendStatics3(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var akashic_label_1 = require("@akashic-extension/akashic-label");

      var def = require("./define");
      /**
       * ひらがな限定キーボード。
       * 英数字、記号も扱いたい場合は `MultiKeyboard` クラスを利用する。
       * 本クラスの利用にはアセットID, g.Fontが必要となる。
       */


      var Keyboard =
      /** @class */
      function (_super) {
        __extends(Keyboard, _super);
        /**
         * 各種パラメータを指定して `Keyboard` のインスタンスを生成する。
         * @param param このエンティティに対するパラメータ
         */


        function Keyboard(param) {
          var _this = _super.call(this, param) || this;

          _this.font = param.font;
          _this.fontSize = "fontSize" in param ? param.fontSize : 72;
          _this.textColor = "textColor" in param ? param.textColor : "#575757";
          _this.backgroundColor = "backgroundColor" in param ? param.backgroundColor : "#252525";
          _this.maxLength = "maxLength" in param ? param.maxLength : 15;
          _this.sceneAssets = param.sceneAssets;
          _this.common = new g.E({
            scene: _this.scene,
            width: 1280,
            height: 720
          });

          _this.append(_this.common);

          _this.kanaKey = new g.E({
            scene: _this.scene,
            width: 1280,
            height: 720
          });

          _this.append(_this.kanaKey);

          _this.keyboardBack = new g.FilledRect({
            scene: _this.scene,
            cssColor: _this.backgroundColor,
            width: 1280,
            height: 720,
            opacity: 0.8
          });

          _this.common.append(_this.keyboardBack);

          var inputtingLabelBackAsset = _this.sceneAssets["inputtingLabelBack"];
          _this.inputtingLabelBack = new g.Pane({
            scene: _this.scene,
            width: inputtingLabelBackAsset.width,
            height: inputtingLabelBackAsset.height,
            x: 8,
            y: 80,
            backgroundImage: inputtingLabelBackAsset
          });
          _this.inputtingLabel = new akashic_label_1.Label({
            scene: _this.scene,
            font: _this.font,
            fontSize: _this.fontSize,
            text: "",
            textColor: _this.textColor,
            width: _this.inputtingLabelBack.width - 20 * 2,
            height: _this.fontSize,
            x: 20,
            y: _this.inputtingLabelBack.height / 2,
            anchorX: 0.0,
            anchorY: 0.5
          });

          _this.inputtingLabelBack.append(_this.inputtingLabel);

          _this.common.append(_this.inputtingLabelBack);

          var _loop_1 = function _loop_1(i) {
            var char = def.hiragana[i];
            var kanaAsset = this_1.sceneAssets[def.toRoman[char]];
            var key = new g.Pane({
              scene: this_1.scene,
              width: kanaAsset.width,
              height: kanaAsset.height,
              x: def.kanaX[i],
              y: def.kanaY[i],
              backgroundImage: kanaAsset,
              touchable: true,
              local: true
            });
            key.pointDown.add(function () {
              if (_this.inputtingLabel.text.length < _this.maxLength) {
                _this.inputtingLabel.text += char;

                _this.inputtingLabel.invalidate();
              }
            });
            this_1.kanaKey.append(key);
          };

          var this_1 = this;

          for (var i = 0; i < def.hiragana.length; i++) {
            _loop_1(i);
          }

          var smallKeyAsset = _this.sceneAssets["small"];
          var smallKey = new g.Pane({
            scene: _this.scene,
            width: smallKeyAsset.width,
            height: smallKeyAsset.height,
            x: def.smallX,
            y: def.smallY,
            backgroundImage: smallKeyAsset,
            touchable: true
          });
          smallKey.pointDown.add(function () {
            /**
             * 入力文字列語尾が小文字にすることが可能であれば小文字へ変換する。
             * 入力文字列語尾が小文字であればもとの文字へ変換する。
             */
            if (_this.inputtingLabel.text.length <= 0) return;

            var moji = _this.inputtingLabel.text.slice(-1);

            var idx = def.canSmall.indexOf(moji);
            var ridx = def.smallChar.indexOf(moji);

            if (idx !== -1 || ridx !== -1) {
              _this.inputtingLabel.text = _this.inputtingLabel.text.slice(0, -1);
              _this.inputtingLabel.text += idx !== -1 ? def.smallChar[idx] : def.canSmall[ridx];

              _this.inputtingLabel.invalidate();
            }
          });

          _this.kanaKey.append(smallKey);

          var voicedKeyAsset = _this.sceneAssets["voiced"];
          var voicedKey = new g.Pane({
            scene: _this.scene,
            width: voicedKeyAsset.width,
            height: voicedKeyAsset.height,
            x: def.voicedX,
            y: def.voicedY,
            backgroundImage: voicedKeyAsset,
            touchable: true,
            local: true
          });
          voicedKey.pointDown.add(function () {
            /**
             * 入力文字列語尾に濁点を付けることが可能であれば濁点を付ける。
             * 入力文字列語尾が濁点付きであればもとの文字へ変換する。
             */
            if (_this.inputtingLabel.text.length <= 0) return;

            var moji = _this.inputtingLabel.text.slice(-1);

            var idx = def.canVoiced.indexOf(moji);
            var ridx = def.voicedChar.indexOf(moji);
            var cidx = def.semiVoicedChar.indexOf(moji);

            if (idx !== -1 || ridx !== -1 || cidx !== -1) {
              _this.inputtingLabel.text = _this.inputtingLabel.text.slice(0, -1);
              _this.inputtingLabel.text += idx !== -1 ? def.voicedChar[idx] : ridx !== -1 ? def.canVoiced[ridx] : def.bChar[cidx];

              _this.inputtingLabel.invalidate();
            }
          });

          _this.kanaKey.append(voicedKey);

          var semiVoicedKeyAsset = _this.sceneAssets["semiVoiced"];
          var semiVoicedKey = new g.Pane({
            scene: _this.scene,
            width: semiVoicedKeyAsset.width,
            height: semiVoicedKeyAsset.height,
            x: def.semiVoicedX,
            y: def.semiVoicedY,
            backgroundImage: semiVoicedKeyAsset,
            touchable: true
          });
          semiVoicedKey.pointDown.add(function () {
            /**
             * 入力文字列語尾に半濁点を付けることが可能であれば半濁点を付ける。
             * 入力文字列語尾が半濁点付きであればもとの文字へ変換する。
             */
            if (_this.inputtingLabel.text.length <= 0) return;

            var moji = _this.inputtingLabel.text.slice(-1);

            var idx = def.canSemiVoiced.indexOf(moji);
            var ridx = def.semiVoicedChar.indexOf(moji);
            var pidx = def.bChar.indexOf(moji);

            if (idx !== -1 || ridx !== -1 || pidx !== -1) {
              _this.inputtingLabel.text = _this.inputtingLabel.text.slice(0, -1);
              _this.inputtingLabel.text += idx !== -1 ? def.semiVoicedChar[idx] : ridx !== -1 ? def.canSemiVoiced[ridx] : def.semiVoicedChar[pidx];

              _this.inputtingLabel.invalidate();
            }
          });

          _this.kanaKey.append(semiVoicedKey); //削除ボタン


          var backSpaceKeyAsset = _this.sceneAssets["backSpaceKey"];
          _this.backSpaceKey = new g.Pane({
            scene: _this.scene,
            width: backSpaceKeyAsset.width,
            height: backSpaceKeyAsset.height,
            x: 1280 - 28 - backSpaceKeyAsset.width,
            y: _this.inputtingLabelBack.y + (_this.inputtingLabelBack.height - backSpaceKeyAsset.height) / 2,
            backgroundImage: backSpaceKeyAsset,
            touchable: true,
            local: true
          });

          _this.backSpaceKey.pointDown.add(function () {
            if (_this.inputtingLabel.text.length > 0) {
              _this.inputtingLabel.text = _this.inputtingLabel.text.slice(0, -1);

              _this.inputtingLabel.invalidate();
            }
          });

          _this.common.append(_this.backSpaceKey);

          return _this;
        }

        Keyboard.prototype.invalidate = function () {
          _super.prototype.modified.call(this);

          this.inputtingLabel.font = this.font;
          this.inputtingLabel.fontSize = this.fontSize;
          this.inputtingLabel.height = this.fontSize;
          this.inputtingLabel.textColor = this.textColor;
          this.inputtingLabel.text = this.inputtingLabel.text.slice(0, this.maxLength);
          this.inputtingLabel.invalidate();
          this.keyboardBack.cssColor = this.backgroundColor;
          this.keyboardBack.modified();
        };

        Keyboard.prototype.destroy = function () {
          _super.prototype.destroy.call(this);

          this.common.destroy();
          this.common = null;
          this.kanaKey.destroy();
          this.kanaKey = null;
          this.keyboardBack.destroy();
          this.keyboardBack = null;
          this.inputtingLabelBack.destroy();
          this.inputtingLabelBack = null;
          this.inputtingLabel.destroy();
          this.inputtingLabel = null;
          this.backSpaceKey.destroy();
          this.backSpaceKey = null;
        };

        Object.defineProperty(Keyboard.prototype, "text", {
          get: function get() {
            return this.inputtingLabel.text;
          },
          set: function set(text) {
            this.inputtingLabel.text = text.slice(0, Math.min(this.maxLength, text.length));
            this.inputtingLabel.invalidate();
          },
          enumerable: true,
          configurable: true
        });
        return Keyboard;
      }(g.E);

      module.exports = Keyboard;
    }, {
      "./define": 16,
      "@akashic-extension/akashic-label": 5
    }],
    14: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics4 = function extendStatics(d, b) {
          _extendStatics4 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics4(d, b);
        };

        return function (d, b) {
          _extendStatics4(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var Keyboard = require("./Keyboard");

      var def = require("./define");
      /**
       * ひらがな、英数字、記号対応キーボード。
       * ひらがなだけ扱いたい場合は `Keyboard` クラスを利用する。
       * 本クラスの利用にはアセットID, g.Fontが必要となる。
       */


      var MultiKeyboard =
      /** @class */
      function (_super) {
        __extends(MultiKeyboard, _super);
        /**
         * 各種パラメータを指定して `MultiKeyboard` のインスタンスを生成する。
         * @param param このエンティティに対するパラメータ
         */


        function MultiKeyboard(param) {
          var _this = _super.call(this, param) || this;

          _this.alphaKey = new g.E({
            scene: _this.scene,
            width: g.game.width,
            height: g.game.height,
            hidden: true
          });

          _this.append(_this.alphaKey);

          _this.symKey = new g.E({
            scene: _this.scene,
            width: g.game.width,
            height: g.game.height,
            hidden: true
          });

          _this.append(_this.symKey);

          var _loop_1 = function _loop_1(i) {
            var char = def.alpha[i];
            var alphaAsset = this_1.scene.assets["a_" + char];
            var key = new g.Pane({
              scene: this_1.scene,
              width: alphaAsset.width,
              height: alphaAsset.height,
              x: def.alphaX[i],
              y: def.alphaY[i],
              backgroundImage: alphaAsset,
              touchable: true,
              local: true
            });
            key.pointDown.add(function () {
              if (_this.inputtingLabel.text.length < _this.maxLength) {
                _this.inputtingLabel.text += def.alpha[i];

                _this.inputtingLabel.invalidate();
              }
            });
            this_1.alphaKey.append(key);
          };

          var this_1 = this;

          for (var i = 0; i < def.alpha.length; i++) {
            _loop_1(i);
          }

          var _loop_2 = function _loop_2(i) {
            var char = def.digit[i];
            var digitAsset = this_2.scene.assets["d_" + (i + 1) % 10];
            var key = new g.Pane({
              scene: this_2.scene,
              width: digitAsset.width,
              height: digitAsset.height,
              x: def.symX[i],
              y: def.symY[0],
              backgroundImage: digitAsset,
              touchable: true,
              local: true
            });
            key.pointDown.add(function () {
              if (_this.inputtingLabel.text.length < _this.maxLength) {
                _this.inputtingLabel.text += char;

                _this.inputtingLabel.invalidate();
              }
            });
            this_2.symKey.append(key);
          };

          var this_2 = this;

          for (var i = 0; i < def.digit.length; i++) {
            _loop_2(i);
          }

          var _loop_3 = function _loop_3(i) {
            var char = def.symbol[i];
            var SymAsset = this_3.scene.assets["sym_" + i];
            var key = new g.Pane({
              scene: this_3.scene,
              width: SymAsset.width,
              height: SymAsset.height,
              x: def.symX[i],
              y: def.symY[Math.floor(i / 10) + 1],
              backgroundImage: SymAsset,
              touchable: true,
              local: true
            });
            key.pointDown.add(function () {
              if (_this.inputtingLabel.text.length < _this.maxLength) {
                _this.inputtingLabel.text += char;

                _this.inputtingLabel.invalidate();
              }
            });
            this_3.symKey.append(key);
          };

          var this_3 = this;

          for (var i = 0; i < def.symbol.length; i++) {
            _loop_3(i);
          }

          var convKanaAsset = _this.scene.assets["toKanaLetters"];
          _this.convKana = new g.Pane({
            scene: _this.scene,
            width: convKanaAsset.width,
            height: convKanaAsset.height,
            x: def.convX[0],
            y: def.convY,
            backgroundImage: convKanaAsset,
            touchable: true,
            local: true,
            hidden: true
          });

          _this.convKana.pointDown.add(function () {
            _this.alphaKey.hide();

            _this.symKey.hide();

            _this.kanaKey.show();

            _this.convAlpha.x = def.convX[0];

            _this.convAlpha.modified();

            _this.convKana.hide();

            _this.convAlpha.show();

            _this.convSym.show();
          });

          _this.common.append(_this.convKana);

          var convAlphaAsset = _this.scene.assets["toAlphaLetters"];
          _this.convAlpha = new g.Pane({
            scene: _this.scene,
            width: convAlphaAsset.width,
            height: convAlphaAsset.height,
            x: def.convX[0],
            y: def.convY,
            backgroundImage: convAlphaAsset,
            touchable: true,
            local: true
          });

          _this.convAlpha.pointDown.add(function () {
            _this.kanaKey.hide();

            _this.symKey.hide();

            _this.alphaKey.show();

            _this.convAlpha.hide();

            _this.convKana.show();

            _this.convSym.show();
          });

          _this.common.append(_this.convAlpha);

          var convSymAsset = _this.scene.assets["toSymLetters"];
          _this.convSym = new g.Pane({
            scene: _this.scene,
            width: convSymAsset.width,
            height: convSymAsset.height,
            x: def.convX[1],
            y: def.convY,
            backgroundImage: convSymAsset,
            touchable: true,
            local: true
          });

          _this.convSym.pointDown.add(function () {
            _this.kanaKey.hide();

            _this.alphaKey.hide();

            _this.symKey.show();

            _this.convAlpha.x = def.convX[1];

            _this.convAlpha.modified();

            _this.convSym.hide();

            _this.convKana.show();

            _this.convAlpha.show();
          });

          _this.common.append(_this.convSym);

          return _this;
        }

        MultiKeyboard.prototype.destroy = function () {
          _super.prototype.destroy.call(this);

          this.alphaKey.destroy();
          this.alphaKey = null;
          this.symKey.destroy();
          this.symKey = null;
          this.convKana.destroy();
          this.convKana = null;
          this.convAlpha.destroy();
          this.convAlpha = null;
          this.convSym.destroy();
          this.convSym = null;
        };

        return MultiKeyboard;
      }(Keyboard);

      module.exports = MultiKeyboard;
    }, {
      "./Keyboard": 13,
      "./define": 16
    }],
    15: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics5 = function extendStatics(d, b) {
          _extendStatics5 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics5(d, b);
        };

        return function (d, b) {
          _extendStatics5(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Ranking =
      /** @class */
      function (_super) {
        __extends(Ranking, _super);

        function Ranking(scene, font) {
          var _this = _super.call(this, {
            scene: scene,
            width: 440,
            height: 320,
            x: 100,
            y: -1000,
            cssColor: "white"
          }) || this;

          var nameLabels = [];
          var hitLabels = [];
          var numLabels = [];

          _this.append(new g.Label({
            scene: scene,
            font: font,
            fontSize: 15,
            text: "順位",
            x: 10,
            y: 6
          }));

          _this.append(new g.Label({
            scene: scene,
            font: font,
            fontSize: 15,
            text: "名前",
            x: 200,
            y: 6
          }));

          _this.append(new g.Label({
            scene: scene,
            font: font,
            fontSize: 15,
            text: "当てた回数",
            x: 340,
            y: 6
          }));

          var line = new g.FilledRect({
            scene: scene,
            width: 430,
            height: 3,
            x: 5,
            y: 30,
            cssColor: "gray"
          });

          _this.append(line);

          for (var i = 0; i < 5; i++) {
            var label = new g.Label({
              scene: scene,
              font: font,
              fontSize: 24,
              text: "",
              x: 10,
              y: i * 60 + 40
            });

            _this.append(label);

            numLabels.push(label);
            label = new g.Label({
              scene: scene,
              font: font,
              fontSize: 24,
              text: "",
              x: 120,
              y: i * 60 + 40
            });

            _this.append(label);

            nameLabels.push(label);
            label = new g.Label({
              scene: scene,
              font: font,
              fontSize: 24,
              text: "",
              x: 360,
              y: i * 60 + 40
            });

            _this.append(label);

            hitLabels.push(label);
          }

          _this.setPlayers = function (players) {
            //ソート
            var ps = players.sort(function (a, b) {
              return b.life - a.life || b.hitCnt - a.hitCnt;
            });

            for (var i = 0; i < 5; i++) {
              if (ps.length - 1 < i) break;
              ps[i].show();
              ps[i].x = 50;
              ps[i].y = i * 60 + 30;

              _this.append(ps[i]);

              ps[i].setRanking();
              var label = numLabels[i];
              label.text = i + 1 + ":";
              label.invalidate();
              label = nameLabels[i];
              label.text = ps[i].name;
              label.invalidate();
              label = hitLabels[i];
              label.text = "" + ps[i].hitCnt;
              label.invalidate();
            }
          };

          return _this;
        }

        return Ranking;
      }(g.FilledRect);

      exports.Ranking = Ranking;
    }, {}],
    16: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 利用するひらがな
       */

      exports.hiragana = "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん";
      /**
       * 利用する数字
       */

      exports.digit = "1234567890";
      /**
       * 利用するアルファベット
       */

      exports.alpha = "abcdefghijklmnopqrstuvwxyz";
      /**
       * 利用する記号
       */

      exports.symbol = "'，．・？！＝～ー（）「」＜＞＆＃＄％★";
      /**
       * 濁点を付けることが可能なひらがな
       */

      exports.canVoiced = "かきくけこさしすせそたちつてとはひふへほ";
      /**
       * 半濁点を付けることが可能なひらがな
       */

      exports.canSemiVoiced = "はひふへほ";
      /**
       * 小文字にすることが可能なひらがな
       */

      exports.canSmall = "あいうえおつやゆよわ";
      /**
       * 濁点付きひらがな
       */

      exports.voicedChar = "がぎぐげござじずぜぞだぢづでどばびぶべぼ";
      /**
       * 半濁点付きひらがな
       */

      exports.semiVoicedChar = "ぱぴぷぺぽ";
      /**
       * 小文字ひらがな
       */

      exports.smallChar = "ぁぃぅぇぉっゃゅょゎ";
      /**
       * ばびぶべぼ
       */

      exports.bChar = "ばびぶべぼ";
      /**
       * ひらがなローマ字変換
       */

      exports.toRoman = {
        あ: "a",
        い: "i",
        う: "u",
        え: "e",
        お: "o",
        か: "ka",
        き: "ki",
        く: "ku",
        け: "ke",
        こ: "ko",
        さ: "sa",
        し: "si",
        す: "su",
        せ: "se",
        そ: "so",
        た: "ta",
        ち: "ti",
        つ: "tu",
        て: "te",
        と: "to",
        な: "na",
        に: "ni",
        ぬ: "nu",
        ね: "ne",
        の: "no",
        は: "ha",
        ひ: "hi",
        ふ: "hu",
        へ: "he",
        ほ: "ho",
        ま: "ma",
        み: "mi",
        む: "mu",
        め: "me",
        も: "mo",
        や: "ya",
        ゆ: "yu",
        よ: "yo",
        ら: "ra",
        り: "ri",
        る: "ru",
        れ: "re",
        ろ: "ro",
        わ: "wa",
        を: "wo",
        ん: "nn"
      };
      /**
       * ひらがなキー座標
       */

      exports.kanaX = [8, 88, 168, 248, 328, 444, 524, 604, 684, 764, 880, 960, 1040, 1120, 1200, 8, 88, 168, 248, 328, 444, 524, 604, 684, 764, 880, 960, 1040, 1120, 1200, 8, 88, 168, 248, 328, 444, 580, 716, 880, 960, 1040, 1120, 1200, 8, 144, 280];
      exports.kanaY = [216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 504, 504, 504];
      /**
       * 「小」「゛」「゜」キー座標
       */

      exports.smallX = 444;
      exports.smallY = 504;
      exports.voicedX = 580;
      exports.voicedY = 504;
      exports.semiVoicedX = 716;
      exports.semiVoicedY = 504;
      /**
       * アルファベットキー座標
       */

      exports.alphaX = [8, 167, 326, 485, 645, 804, 963, 1122, 8, 167, 326, 485, 645, 804, 963, 1122, 8, 167, 326, 485, 645, 804, 963, 1122, 8, 167];
      exports.alphaY = [216, 216, 216, 216, 216, 216, 216, 216, 312, 312, 312, 312, 312, 312, 312, 312, 408, 408, 408, 408, 408, 408, 408, 408, 504, 504];
      /**
       * 記号キー座標
       */

      exports.symX = [8, 136, 264, 393, 521, 649, 777, 906, 1034, 1162, 8, 136, 264, 393, 521, 649, 777, 906, 1034, 1162];
      exports.symY = [216, 309, 402];
      /**
       * キーボード変更キー座標
       */

      exports.convX = [880, 1092];
      exports.convY = 504;
    }, {}],
    17: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics6 = function extendStatics(d, b) {
          _extendStatics6 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics6(d, b);
        };

        return function (d, b) {
          _extendStatics6(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var player_1 = require("./player");

      var Ball_1 = require("./Ball");

      var Ranking_1 = require("./Ranking");

      var Game =
      /** @class */
      function (_super) {
        __extends(Game, _super);

        function Game(pram) {
          var _this = _super.call(this, pram) || this;

          var scene = pram.scene;
          var timeline = new akashic_timeline_1.Timeline(scene); //プレイヤーのリスト

          var players = {};
          var isStart = false;
          var timeLimit = 120;
          var dieCnt = 0; //死んだ数
          //背景

          var bg = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "green",
            opacity: 0.8
          });

          _this.append(bg); //コート


          var court = new g.Sprite({
            scene: scene,
            src: scene.assets["court"],
            y: 30
          });
          bg.append(court);
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            fontWeight: g.FontWeight.Bold,
            size: 15
          });
          var font2 = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            fontWeight: g.FontWeight.Bold,
            size: 24
          }); //時間表示

          var labelTime = new g.Label({
            scene: scene,
            font: font2,
            fontSize: 24,
            text: "ボールぶつけ",
            x: 220,
            y: 6,
            width: 200,
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            textColor: "white"
          });

          _this.append(labelTime); //情報表示


          var labelInfo = new g.Label({
            scene: scene,
            font: font2,
            fontSize: 20,
            text: "",
            x: 35,
            y: 5,
            textColor: "white"
          });

          _this.append(labelInfo); //カーソル用ローカルエンティティ


          var localE = new g.E({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            touchable: true,
            local: true,
            opacity: 0.8
          });

          _this.append(localE); //自分のプレイヤー位置表示用カーソル


          var cursorNow = new g.Sprite({
            scene: scene,
            x: -70,
            width: 70,
            height: 70,
            src: scene.assets["cursor"],
            srcX: 70,
            touchable: true
          });
          localE.append(cursorNow); //移動先表示位置カーソル

          var cursorNext = new g.Sprite({
            scene: scene,
            x: -70,
            width: 70,
            height: 70,
            src: scene.assets["cursor"],
            srcX: 70
          });
          localE.append(cursorNext); //プレイヤーを載せるエンティティ

          var playerE = new g.E({
            scene: scene,
            width: g.game.width,
            height: g.game.height
          });

          _this.append(playerE); //ボールを載せるエンティティ


          var ballE = new g.E({
            scene: scene
          });

          _this.append(ballE); //ボール


          var ball = new Ball_1.Ball(scene); //ランキング

          var ranking = new Ranking_1.Ranking(scene, font2); //音声再生

          var playSound = function playSound(name, vol) {
            var audio = scene.assets[name].play();
            audio.changeVolume(vol);
            return audio;
          }; //BGMの切り替えボタン


          var bgm = playSound("bgm", 0.4);
          var buttonBGM = new g.FilledRect({
            scene: scene,
            x: 450,
            y: 5,
            width: 80,
            height: 30,
            cssColor: "white",
            touchable: true,
            local: true
          });
          localE.append(buttonBGM);
          buttonBGM.pointDown.add(function () {
            if (buttonBGM.cssColor === "white") {
              bgm.changeVolume(0);
              buttonBGM.cssColor = "gray";
            } else {
              bgm.changeVolume(0.4);
              buttonBGM.cssColor = "white";
            }

            buttonBGM.modified();
          });
          var labelBGM = new g.Label({
            scene: scene,
            font: font2,
            x: 14,
            y: 2,
            fontSize: 20,
            text: "BGM"
          });
          buttonBGM.append(labelBGM); //SEの切り替えボタン

          var seVol = 0.5;
          var buttonSE = new g.FilledRect({
            scene: scene,
            x: 550,
            y: 5,
            width: 80,
            height: 30,
            cssColor: "white",
            touchable: true,
            local: true
          });
          localE.append(buttonSE);
          var labelSE = new g.Label({
            scene: scene,
            font: font2,
            x: 25,
            y: 2,
            fontSize: 20,
            text: "SE"
          });
          buttonSE.append(labelSE);
          buttonSE.pointDown.add(function () {
            if (buttonSE.cssColor === "white") {
              seVol = 0;
              buttonSE.cssColor = "gray";
            } else {
              seVol = 0.5;
              buttonSE.cssColor = "white";
            }

            buttonSE.modified();
          });

          var finish = function finish() {
            isStart = false;
            labelTime.text = "終了";
            labelTime.invalidate();
            var arr = Object.keys(players).map(function (key) {
              return players[key];
            });

            _this.append(ranking);

            timeline.create(ranking).moveY(30, 4000).call(function () {
              ranking.setPlayers(arr);
            });
            playSound("se_timeup", seVol);
          }; //投げる


          var throwBall = function throwBall(p) {
            ball.isMove = true;
            ball.isCatch = false;
            ball.moveY = Math.sin(p.radian);
            ball.moveX = Math.cos(p.radian);
            ball.speed = p.speed + 2;
            p.isCatch = false; //自分の投げたボールに当たらないように無敵時間を作る

            p.isCollision = false;
            scene.setTimeout(function () {
              p.isCollision = true;
            }, 700);
            playSound("se_move", seVol);
          }; //ゲームループ


          _this.update.add(function () {
            if (!isStart) return;
            timeLimit -= 1 / 30;
            var min = Math.floor(timeLimit / 60);
            var sec = Math.floor(timeLimit % 60);
            labelTime.text = min + ":" + ('00' + sec).slice(-2);

            if (timeLimit <= 0) {
              finish();
              return;
            }

            labelTime.invalidate();

            var _loop_1 = function _loop_1(key) {
              var p = players[key]; //botの時移動先を指定

              if (!p.isHuman && !p.isMove) {
                if (g.game.random.get(0, 50) === 0) {
                  var x = g.game.random.get(50, 590);
                  var y = g.game.random.get(60, 320);
                  setMove(p.tag, x, y);
                }
              }

              if (p.isCollision && !p.isDie && g.Collision.withinAreas(p, ball, 40) && !ball.isCatch) {
                if (!ball.isMove || p.stateCatch === 1) {
                  //落ちている時と掴もうとしているとき掴む
                  ball.player = p;
                  p.isMove = false; //止まる

                  ball.catch();
                  p.isCatch = true;
                  cursorNext.x = cursorNow.x;
                  cursorNext.y = cursorNow.y;
                  cursorNext.modified();
                  playSound("se_move", seVol);
                } else {
                  //動いているときは当たる
                  ball.moveX = -ball.moveX;
                  ball.moveY = -ball.moveY; //エフェクト作成

                  var effect_1 = new g.FrameSprite({
                    scene: scene,
                    src: scene.assets["effect"],
                    width: 120,
                    height: 120,
                    frames: [0, 1, 2],
                    interval: 100,
                    x: ball.x - 50,
                    y: ball.y - 50,
                    opacity: 0.5
                  });
                  effect_1.start();
                  ballE.append(effect_1);
                  ball.player.hitCnt++; //反動で飛ばされる

                  timeline.create(p).moveBy(10 * -(ball.speed * ball.moveX), 0, 500).call(function () {
                    if (g.game.selfId === key) {
                      cursorNow.moveTo(p.x - 10, p.y - 8);
                      cursorNow.modified();
                      cursorNext.moveTo(p.x - 10, p.y - 8);
                      cursorNext.modified();
                    }

                    p.stop();
                    var px = p.x + p.width / 2;

                    if (p.life <= 0 || px < 30 || px > 610) {
                      p.die();
                      scene.setTimeout(function () {
                        if (g.game.selfId === key) {
                          cursorNow.hide();
                          cursorNext.hide();
                        }

                        p.hide();
                      }, 3000);
                      labelInfo.textColor = "red";
                      labelInfo.text = "OUT " + p.name;
                      dieCnt++;

                      if (dieCnt >= Object.keys(players).length - 1) {
                        finish();
                      }
                    } else {
                      labelInfo.textColor = "yellow";
                      labelInfo.text = "HIT " + p.name;
                    }

                    labelInfo.invalidate();
                    effect_1.destroy();
                  });
                  scene.setTimeout(function () {
                    ball.stop();
                  }, 200);
                  p.stop();
                  p.hit(ball.moveX);
                  playSound("se_hit", seVol);
                }
              } //ボールをプレイヤーに追従


              if (p.isCatch) {
                ball.x = p.x + (p.width - ball.width) / 2 + 20 * p.direction;
                ball.y = p.y + (p.height - ball.height) / 2 + 8;
                ball.modified();
                p.time += 1 / 30;
              } else {
                p.time = 0;
              } //ボールを長く掴んでいる場合強制的に投げる


              if (p.time > 3) {
                throwBall(p);
              }

              if (!p.isMove || p.isDie) return "continue"; //角度と速度から移動量を求めて加算

              p.speed += 0.1;
              p.y += Math.sin(p.radian) * p.speed;
              p.x += Math.cos(p.radian) * p.speed;
              p.distance -= p.speed;
              p.modified();

              if (g.game.selfId === key) {
                cursorNow.moveTo(p.x - 10, p.y - 8);
                cursorNow.modified();
              } //カーソル位置まできたら止まる


              if (p.distance <= 0) {
                //p.isMove = false;
                p.stop(); //ボールを持っていたら投げる

                if (p.isCatch) {
                  throwBall(p);
                }
              }
            };

            for (var key in players) {
              _loop_1(key);
            } //ボールの移動


            if (ball.isMove && !ball.isCatch) {
              ball.moveBy(ball.moveX * ball.speed, ball.moveY * ball.speed);
              ball.modified(); //画面端に当たった場合反転

              if (ball.x < 0 || ball.x > g.game.width - ball.width) {
                ball.moveX = -ball.moveX;
                ball.speed += 0.3; //加速
              }

              if (ball.y < 15 || ball.y > g.game.height - ball.height + 15) {
                ball.moveY = -ball.moveY;
                ball.speed += 0.3;
              }
            }
          }); //移動先を設定


          var setMove = function setMove(id, x2, y2) {
            if (players[id] === undefined) return; //角度と距離を求める

            var p = players[id];
            var x = p.x - 10;
            var y = p.y - 8;
            p.radian = Math.atan2(y2 - y, x2 - x);
            p.distance = Math.sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y));
            p.isMove = true;
            p.speed = 3; //向きを変える

            p.setAngle(x < x2 ? 1 : -1);
            p.move();
          }; //グローバルイベント


          scene.message.add(function (msg) {
            // 関係ないイベントは無視して抜ける
            if (!msg.data || !msg.data.event) return;
            var ev = msg.data.event;
            setMove(ev.player.id, ev.point.x, ev.point.y);
          }); //キャッチできる状態にする(グローバルイベント)

          scene.message.add(function (msg) {
            // 関係ないイベントは無視して抜ける
            if (!msg.data || !msg.data.msg) return;

            if (msg.data.msg === "catching") {
              var p = players[msg.data.player.id];
              if (!p.isCollision || p.isCatch || p.isDie) return;
              p.catch();
            }
          }); //移動先の指定

          localE.pointDown.add(function (ev) {
            var p = players[ev.player.id];
            if (!isStart || !p || !p.isCollision || p.isDie) return;
            if (ev.point.x < 50) ev.point.x = 50;
            if (ev.point.x > 630) ev.point.x = 630;
            if (ev.point.y < 60) ev.point.y = 60;
            if (ev.point.y > 350) ev.point.y = 350;
            ev.point.x = ev.point.x - 10 - 35;
            ev.point.y = ev.point.y - 32 - 25; //移動先カーソル位置変更

            cursorNext.x = ev.point.x;
            cursorNext.y = ev.point.y;
            cursorNext.modified(); //グローバルイベント

            g.game.raiseEvent(new g.MessageEvent({
              event: {
                player: ev.player,
                point: ev.point
              }
            }));
          }); //掴める状態にする

          cursorNow.pointDown.add(function (e) {
            if (!isStart) return; //グローバルイベント

            g.game.raiseEvent(new g.MessageEvent({
              msg: "catching",
              player: e.player
            }));
          }); //ゲーム開始

          _this.start = function (users, life, time) {
            timeLimit = time * 60; //プレイヤー生成

            for (var id in users) {
              var name_1 = users[id];
              var src = scene.assets["player"];
              var player = new player_1.Player(scene, id, name_1, life, true, font);
              playerE.append(player);
              players[id] = player;
              ballE.append(ball);

              if (id === g.game.selfId) {
                cursorNow.x = player.x - 10;
                cursorNow.y = player.y - 8;
                cursorNow.modified();
              }
            }

            ;
            var num = Object.keys(users).length;

            if (num < 5) {
              for (var i = 0; i < 5 - num; i++) {
                var name_2 = "bot" + (i + 1);
                var src = scene.assets["player"];
                var id = "" + i;
                var player = new player_1.Player(scene, id, name_2, life, false, font);
                playerE.append(player);
                players[id] = player;
                ballE.append(ball);
              }
            }

            isStart = true;
            playSound("se_start", seVol);
          };

          return _this;
        }

        return Game;
      }(g.E);

      exports.Game = Game;
    }, {
      "./Ball": 11,
      "./Ranking": 15,
      "./player": 19,
      "@akashic-extension/akashic-timeline": 10
    }],
    18: [function (require, module, exports) {
      "use strict";

      var Input_1 = require("./Input");

      var key = require("./define");

      var game_1 = require("./game");

      var game = g.game;

      function main() {
        var assetIds = [];
        var consonants = ["", "k", "s", "t", "n", "h", "m", "r"];
        consonants.forEach(function (v) {
          assetIds.push(v + "a", v + "i", v + "u", v + "e", v + "o");
        });

        for (var i = 0; i < key.alpha.length; i++) {
          assetIds.push("a_" + key.alpha[i]);
        }

        for (var i = 0; i < 10; i++) {
          assetIds.push("d_" + i);
        }

        for (var i = 0; i < 20; i++) {
          assetIds.push("sym_" + i);
        }

        assetIds.push("ya", "yu", "yo", "wa", "wo", "nn", "small", "voiced", "semiVoiced", "toKanaLetters", "toAlphaLetters", "toSymLetters", "inputtingLabelBack", "backSpaceKey", "open", "close", "notosansFont", "notosansGlyph", "ball", "cursor", "button", "court", "player_body", "player_head", "effect", "bgm", "se_move", "se_hit", "se_start", "se_timeup");
        var scene = new g.Scene({
          game: game,
          assetIds: assetIds
        });
        scene.loaded.add(function () {
          var game = new game_1.Game({
            scene: scene
          });
          scene.append(game);
          var input = new Input_1.Input({
            scene: scene
          });

          input.endEvent = function () {
            input.hide();
            game.start(input.users, input.life, input.time);
          };

          scene.append(input);
        });
        g.game.pushScene(scene);
      }

      module.exports = main;
    }, {
      "./Input": 12,
      "./define": 16,
      "./game": 17
    }],
    19: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var _extendStatics7 = function extendStatics(d, b) {
          _extendStatics7 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics7(d, b);
        };

        return function (d, b) {
          _extendStatics7(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      }); //プレイヤークラス

      var Player =
      /** @class */
      function (_super) {
        __extends(Player, _super);

        function Player(scene, id, name, life, isHuman, font) {
          var _this = _super.call(this, {
            scene: scene,
            x: g.game.random.get(30, 640 - 50 - 30),
            y: g.game.random.get(50, 360 - 50 - 20),
            width: 50,
            height: 50,
            tag: id
          }) || this;

          _this.isMove = false;
          _this.isCollision = true;
          _this.stateCatch = 0;
          _this.isCatch = false;
          _this.name = name;
          _this.life = life;
          _this.isDie = false;
          _this.hitCnt = 0;
          _this.isHuman = isHuman;
          _this.time = 0; //体のフレームをライフによって変えて取得

          var getFrames = function getFrames(arr) {
            return arr.map(function (i) {
              return i + (3 - _this.life) * 6;
            });
          }; //影


          var srcShadow = scene.assets["cursor"];
          var shadow = new g.Sprite({
            scene: scene,
            src: srcShadow,
            width: 40,
            height: 25,
            y: 25,
            x: 5,
            srcY: 20
          });

          _this.append(shadow); //体


          var src = scene.assets["player_body"];
          var body = new g.FrameSprite({
            scene: scene,
            src: src,
            y: -4,
            width: 50,
            height: 50,
            frames: getFrames([1, 3]),
            interval: 100
          });
          body.start();

          _this.append(body); //頭


          var head = new g.FrameSprite({
            scene: scene,
            src: scene.assets["player_head"],
            y: -27,
            width: 50,
            height: 50,
            frames: [1, 3],
            scaleX: 0.9,
            scaleY: 0.9,
            interval: 100
          });
          head.start();
          body.append(head); //名前表示用ラベル

          var labelName = new g.Label({
            scene: scene,
            font: font,
            fontSize: 14,
            text: name,
            y: -45,
            x: -25,
            textAlign: g.TextAlign.Center,
            widthAutoAdjust: false,
            width: 110
          });

          _this.append(labelName); //方向転換


          _this.setAngle = function (x) {
            _this.direction = x;
            body.scaleX = x;
            body.modified();
          }; //止まる


          _this.stop = function () {
            _this.isMove = false;

            if (!_this.isDie) {
              body.frames = getFrames([1, 3]);
              body.frameNumber = 0;
              head.frames = [1, 3];
              head.frameNumber = 0;
              body.angle = 0;
              body.modified();
            }
          }; //動きだす


          _this.move = function () {
            if (!_this.isDie) {
              _this.isMove = true;
              body.frames = getFrames([0, 1, 2, 1]);
              body.frameNumber = 0;
              head.frames = [0, 1, 2, 1];
              head.frameNumber = 0;
              body.modified();
            }
          }; //取る


          _this.catch = function () {
            if (_this.stateCatch === 0) {
              _this.stateCatch = 1;
              body.frames = getFrames([4]);
              body.frameNumber = 0;

              _this.modified();

              scene.setTimeout(function () {
                _this.stateCatch = 2;

                _this.stop();

                scene.setTimeout(function () {
                  _this.stateCatch = 0;
                }, 600);
              }, 600);
            }
          }; //当たる


          _this.hit = function (x) {
            body.frames = getFrames([5]);
            body.frameNumber = 0;
            head.frames = [5];
            head.frameNumber = 0;
            body.angle = x > 0 ? -45 : 45;
            body.modified();
            if (_this.life > 0) _this.life--; //無敵時間

            _this.isCollision = false;
            scene.setTimeout(function () {
              _this.isCollision = true;
            }, 1000);
          }; //死亡


          _this.die = function () {
            body.frames = [18];
            body.frameNumber = 0;
            head.frames = [6];
            head.frameNumber = 0;
            body.angle = 0;
            body.modified();
            _this.isDie = true;
            _this.life = 0;
          };

          var isEnd = false;

          _this.update.add(function () {
            if (_this.isDie && !isEnd) {
              if (head.y < 5) {
                head.y += 3;
                head.modified();
              } else {
                head.x += _this.direction * 0.2;
                head.angle += _this.direction;
                head.modified();
              }
            }
          });

          _this.setRanking = function () {
            head.x = 0;
            labelName.hide();

            _this.show();

            isEnd = true;
          };

          return _this;
        }

        return Player;
      }(g.E);

      exports.Player = Player;
    }, {}]
  }, {}, [18])(18);
});